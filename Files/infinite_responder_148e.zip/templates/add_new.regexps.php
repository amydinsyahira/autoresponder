<br />
<FORM action="regexps.php" method=POST>
<strong>New Regexp:</strong><br />
<center>
   <input name="regx" size=101 maxlength=1024 value="" class="fields">
</center>
<table cellpadding="0" cellspacing="0" border="0" align="right">
   <tr>
      <td>
           <input type="hidden" name="action" value="add">
           <input type="submit" name="addreg" value="Add a Regexp" alt="Add a Regexp">
      </td>
   </tr>
</table>
</FORM>
