</td></tr></table>
</center>
<br />
<center>
<table cellpadding="0" cellspacing="0" border="0">
   <tr>
      <td width="600">
         <font size="3" color="#330000">You can add messages from the "Edit" display.</font>
      </td>
      <td>
         <form action="responders.php" method=POST>
            <input type="hidden" name="action" value="create">
            <input type="Submit" name="submit" value="Add a Responder">
         </form>
      </td>
   </tr>
</table>
</center>
