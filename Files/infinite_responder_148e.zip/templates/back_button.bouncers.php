<br />
<div style="width:550px">
     <div style="width:50%; float: left;">
        <FORM action="bouncers.php" method=POST> 
           <input type="hidden" name="action" value="<?php echo $return_action; ?>">
           <input type="hidden" name="b_ID"   value="<?php echo $bouncer_id; ?>">
           <input type="submit" name="back"   value="<< Back" alt="<< Back">
        </FORM> 
     </div>
     <div style="width:50%; float: right;">
     </div>
</div>

