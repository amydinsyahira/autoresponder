<?php 
# ------------------------------------------------
# License and copyright:
# See license.txt for license information.
# ------------------------------------------------

# Database information goes here. Server, user, password and database.
$MySQL_server   = '';
$MySQL_user     = '';
$MySQL_password = '';
$MySQL_database = '';

# ------------------------------------------------

# Get the rest of the config auto-magically
include("get_config_vars.php");
?>
