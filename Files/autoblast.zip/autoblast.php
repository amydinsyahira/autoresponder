<?php
// Command-line blast email sender
// By Dan Lapoint (http://www.threevolve.org)
// Copyright ©2010 Dan Lapoint. All Rights Reserved
//
// License: You may use this script and modify it to suit your needs, as long this credit/copyright/license notice remains intact.
// If you find this useful, consider buying me a beer. Email me for PayPal info. Thanks!

// ================ NOTES:
// Make a database with different tables. These will be your "lists". All you need in a table is an column named "email" set as primary key. I use varchar(255) as the type.
// Each table is a different "list" for blasting emails. 
//
// When you're ready to test, make sure $test = 1; and $dry = 0;
// Then from the command line type:     php autoblast.php
// When you're ready to send for real, change $test = 1; to $test = 0; and then change $dry = 0; back to $dry = 1;
// Make sure you have the number of recipients you expected, and then change $dry = 1; back to $dry = 0;
// Now from the command line type:     php autoblast.php
// Sit back and watch the emails go out 


// Settings:
//
// 1 = Run test conditional (test mode)
// 0 = Run not a test conditional (live mode)
$test = 1;

$test_list = "name_of_test_table_here"; // Enter the name of the mysql table which contains the list of emails for your testing.
$live_list = "name_of_live_table_here"; // Enter the name of the mysql table which contains the list of emails for the final LIVE blast

// 1 = dry run (runs through list, but doesn't actually send anything)
// 0 = Really send emails! 
$dry = 1;

// Database settings
$mysql_host = "localhost"; // 99.9% won't need to change this - but if you do, it's the IP or hostname of your database server.
$mysql_user = "enter_mysql_username_here"; // Username to connect to mysql db
$mysql_pass = "enter_mysql_password_here"; // Password to connect to mysql db
$mysql_db   = "enter_db_name_here"; // Which database to use

// Message stuffs
$subjline = "Subject Line Here"; // Enter the subject of your email
$from_who = "Name of Sender"; // Enter the name (NOT email address) of the sender
$from_eml = "sender@example.com"; // Enter the email address of the sender

// The message!
$the_message = '
<!-- Paste the HTML of your email here. Make sure to use absolute (http://www.example.com/example.html) URLs for links and images, and NOT relative (images/header.jpg) URLs.
If you use relative URLs, images won\'t load and links won\'t work. Also, make sure you escape any single quotation marks in your code, like this: \'  -->
';

// Don't edit this
$con = mysql_connect($mysql_host, $mysql_user, $mysql_pass);
if ( $con ) { echo "Connected to DB\n";}
else { echo "DB connection failed\n"; die(); }

// Don't edit this, either
$sel = mysql_select_db($mysql_db);
if ( $sel ) { echo "Reading database...\n\n"; }
else { echo "Could not open DB\n\n"; die(); }

// If this is a test
if ( $test == 1 ) {
// Get all the emails from the test list
$sql = "SELECT `email` FROM `".$test_list."` WHERE 1";
// And prepend "[TEST]" to the subject line
$subjins = "[TEST] ";
}
// Otherwise we're sending for real
else {
// Get all the emails from the live list
$sql = "SELECT `email` FROM `".$live_list."` WHERE 1";
// And don't modify the subject line
$subjins = "";
}

// If you edit any of this, horrible things will happen
$res = mysql_query($sql);
$bgc = mysql_num_rows($res);
if ( $res ) { echo "Starting blast - sending $bgc emails...\n\n"; }
else { echo "Error: Could not read from DB"; die(); }
$sent = false;
$ii = 0;
$iii = 0;
while ( $user = mysql_fetch_array($res, MYSQL_ASSOC) ) {
echo $user['email'] . " => ";
$ii++;
if ( $dry == 0 ) {
usleep(250000);
$to = $user['email'];
$subject = $subjins.$subjline;
$message = $the_message;
$headers = 'MIME-Version: 1.0' . "\r\n" .
	'Content-Type: text/html' . "\r\n" .
	'From: '.$from_who.' <'.$from_eml.'>' . "\r\n" .
	'Reply-To: '.$from_who.' <'.$from_eml.'>' . "\r\n" .
	'X-Mailer: PHP/'.phpversion();

$sent = mail($to, $subject, $message, $headers, "-r".$from_eml); }
if ( $sent ) { $iii++; echo "Sent [$ii/$bgc]\n\n"; }
else { echo "Failed [$ii/$bgc]\n\n"; }

}
echo "\n\nDone.\n\n".$ii." users read.\n\n".$iii." messages sent successfully.\n\n";

?>
